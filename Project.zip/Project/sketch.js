/*LOOPER PEDAL CODE, P5 KYLER VANCAMP
* The basic idea is that this functions as a guitar looper pedal, but on a website and it allows you to save loops (download) after.
* For more in-depth explanation, see attached documentation. 
* NOTE: everything except for tone.usermedia and tone player, recorder functions is from previous projects, hence the odd names.
* SEE: @Ard sketch for arduino side. 
*/

//Start is the opening menu, play is the main looper station, end is the download page.
let GameStates = Object.freeze
(
  {
    START: "start",
    PLAY: "play",
    END: "end",
  }
);

let gameStates = GameStates.START;

let port;

let connectButton;
let LEDButtonRecord1;
let LEDButtonRecord2;
let downloadButton;

let buttonToggle = 0;
let buttonToggle2 = 3;
let characterB;

let recordAnim;

let recorder;
let player = null;
let audio = null;
let audio2 = null;
let overdubRecorder;
let overdubPlayer = null;
let mainB = null;
let overB = null;

let mainText = "";
let makeItStop;

let overdubFlag = false; 

//Sprite sheet, see @Media.
function preload() {
  recordAnim = loadImage("media/Sprite-0001.png");
}

//button setup, animation setup, and port setup. I originally had the recorder, motu, and player objects here, but ASYNC and permissinos were both required,
// hence why they are in connect to serial now. 
function setup() 
{
  createCanvas(windowWidth, windowHeight);

  port = createSerial();
  connectButton = createButton("Connect to Ard and audio");
  connectButton.mousePressed(connectToSerial);
  connectButton.position(50, 40);

  makeItStop = createButton("Make It Stop!!!");
  makeItStop.mousePressed(stop);
  makeItStop.hide();
  makeItStop.position(50, 100);

  downloadButton = createButton("Download your abomination... i mean creation.");
  downloadButton.mousePressed(download);
  downloadButton.hide();
  downloadButton.position(50, 100);
 
  characterB = new Character(500, 500,500,500);
  characterB.addAnimation("recording", new SpriteAnimation(recordAnim, 5, 0, 3));
  characterB.addAnimation("playing", new SpriteAnimation(recordAnim, 0, 0, 5));
} 

//Draw is similiar to bug squish wherein it has 3 phases, which is gamestates.
function draw() 
{
  background(220);

  switch(gameStates)//switch for 3 states of website.
  {
    case GameStates.START:
      textAlign(CENTER,CENTER);
      textSize(40);
      text("WELCOME TO THE BEST LOOPER PEDAL!",width/2,height/2-200);
      textSize(25);
      text("After connecting to the arduino, press enter to start!",width/2,height/2-100);
      break;

    case GameStates.PLAY:
      textAlign(CENTER,CENTER);
      textSize(40);
      text("LOOPER STATION",width/2,height/2-200);
      textSize(25);
      text("Press the yellow button to record the main loop. After that, press the blue button to record over the loop.",width/2,height/2-100);
      textSize(15);
      text("If it gets too much, make it stop with the make it stop button! Once you are done, press tab to go to the download page.",width/2,height/2-50);

      let str = port.readUntil('\n');
      if (str!=="")
      {
        str = str.trim();
        if(str === "1")//Main loop button press
        {
          mainText ="Recording..."
          mainRecord();//Record function for main loop 
        }
        else if(str==="0")//Mainloop 2nd button press
        {
          mainText ="Playing!"
          mainPlay();//Record stop, Main loop play
        }

        if(str === "3")//overdub 1st button press
        {
          if(overdubFlag)//if flag implies the user wants to press the button to start a new loop. 
          {
            overdubPlayer.stop();
            overdubPlayer.dispose();
            overdubPlayer = null;
            audio2.pause();
            overdubFlag = false;
          }
          else//If not flag, the user just want to overdub, sending to secondRecord, which is the record function for the overdub button press. 
          {
            secondRecord();
            overdubFlag = true;   
          }
        }

      else if(str==="2")//second Overdub button press
        {
          if(overdubFlag)//if flag active, implies user just recorded overdub, hence goes to secondPlay. which is play for overdub. 
          {
            secondPlay();
          }
          else//If flag is not active, user wants to end loop, and is in the process of doing so, hence the no return value. It simply resets. Possible future fix, set str = 3 in else above.
          {
            return;
          }
        }
      }
      textAlign(CENTER, CENTER);
      textSize(40);
      text(mainText,width/2,500);
  
      makeItStop.show();    
      characterB.draw();
    break;

    case GameStates.END:
    downloadButton.show();
    textAlign(CENTER,CENTER);
    textSize(40);
    text("THANK YOU FOR USING LOOPERSTATION",width/2,height/2-200);
    textSize(25);
    text("Hopefully your loop sounds good!",width/2,height/2-100);
    textSize(15);
    text(":)",width/2,height/2-50);
    break;
  }
  frameRate(10);//So low to allow animation to look more natural. 
}

//Had to change anything which interacts with tone.UserMedia, recorder, and player to be async. This is by design of Tone audio nodes. 
//Many functions were added here, due to an error in the browser which requires the user to interact and allow these functions to be used (Privacy concerns),
// hence the reason await Tone.start() band motu functions are in a connectToSerial function. 
async function connectToSerial()
{
  await Tone.start(); //Result of using async, functionally same as just Tone.start() 
  motu = new Tone.UserMedia();  //"list the inputs and open the third one" From Tone.User media. Creates structure which Allows for audio input, similiar syntax to other Tone.js. 
  await motu.open(); //Same Thing, user interaction and permission required. 

  recorder = new Tone.Recorder();// The recorder for MainLoop.
  overdubRecorder = new Tone.Recorder();// Recorder for overdub. 
  motu.connect(recorder); // Connects mainloop recorder to MOTU.
  motu.connect(overdubRecorder); //Connects overdub recorder to MOTU. 

  port.open('Arduino',9600);
}

//Begins recording for the mainloop.
async function mainRecord()
{
  // console.log("Recording");
  characterB.currentAnimation = "recording";//animation change, or begin if first. 
  recorder.start();//Starts recording recorder, attached to MOTU. Doesnt stop until button pressed again, which is when mainPlay is called and recorder stop occurs. 
}

//Ends recording for the main loop, and plays it back.
async function mainPlay()
{
  // console.log("Playing");
  characterB.currentAnimation = "playing";//animation change
  
  // From the Tone.js Recorder documentation, This saves what the recorder has recorded in recording, and then saves it as mainB, which is used later to download mainLoop. 
  const recording = await recorder.stop();
  mainB = recording;
  const url = URL.createObjectURL(recording);// Variable so that the recording can be player in the website.

  player = new Tone.Player(url).toDestination(); //creates a player with URL, which is the recording. 
  player.loop = true; //player functions, see https://tonejs.github.io/docs/15.0.4/classes/Player.html for more info.
  player.autostart = true; //player functions, see https://tonejs.github.io/docs/15.0.4/classes/Player.html for more info.
  // player = new Tone.Player(recording).toDestination();

  // const url = URL.createObjectURL(recording);
  audio = new Audio(url);//Allows for live listening of loop, 
  audio.loop = true; // allows audio to run indef 
  audio.play(); //begin playback

  // player.loop = true;
  // player.autostart = true;
}

//Starts recording for the second loop, the overdub.
// SEE @mainRecord() for similiar code comments
async function secondRecord()
{
  // console.log("Recording");
  characterB.currentAnimation = "recording";
  overdubRecorder.start();

  // Keep track of time, if time overlaps the mainloop time, then it automatically stops. 
  const loopTime = player.buffer.duration * 1000;
  // overdubStart = millis();
  setTimeout(() => 
    {
      if (overdubFlag) secondPlay();
        overdubFlag = false;
    }, 
    loopTime);
}

// Stops recording and begins playing the overdub. 
// SEE @mainPlay() functionality and notes, its the same. 
async function secondPlay()
{
  // console.log("Playing");
  characterB.currentAnimation = "playing";

  const overdubRecording = await overdubRecorder.stop();
  overB =  overdubRecording;
  const url = URL.createObjectURL( overdubRecording);

  overdubPlayer = new Tone.Player(url).toDestination();
  overdubPlayer.loop = true;
  overdubPlayer.autostart = true;

  audio2 = new Audio(url);
  audio2.loop = true;
  audio2.play();
}

// Animation for recording and playing. 
class SpriteAnimation {
  constructor(spritesheet, startU, startV, duration) {
    this.spritesheet = spritesheet;
    this.u = startU;
    this.v = startV;
    this.duration = duration;
    this.startU = startU;
  }
  draw() {
    image(this.spritesheet, 800,550, 300, 300, this.u * 80, this.v * 80, 80, 80);
    this.u++;
    if (this.u == this.startU + this.duration) {
      this.u = this.startU;
    }
  }
}
// Animation set up 
class Character {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.currentAnimation = null;
    this.animations = {};
  }
  addAnimation(key, animation) {
    this.animations[key] = animation;
  }

  draw() {
    let animation = this.animations[this.currentAnimation];
      if (animation) {
      push();
      animation.draw();
      pop();
    }
  }
}

//Key cases, if enter then go to gamestate play, if tab then gamestate end.
function keyPressed() 
{
  switch(keyCode) {
    case ENTER:
      gameStates = GameStates.PLAY;
      break;
    case TAB:
      gameStates = GameStates.END;
      break
  }
}

// Used for the make it stop button, stops all loops and sets them to null so that you can record once again. See documentation for specific function functionality. 
function stop()
{
  mainText = "Stopped!";
  player.stop();
  player.dispose();
  player = null;

  audio.pause();
  audio = null;
  audio2.pause();
  audio2 = null; 

  overdubPlayer.stop();
  overdubPlayer.dispose();
  overdubPlayer = null;

  overdubFlag = false; 

  characterB.currentAnimation = null;
  port.write("1\n");
}

// Download function, using Filesaver imported in index.  
function download() 
{
  saveAs(mainB,'mainLoop.wav');
  saveAs(overB,'overDub.wav');
}


// async function secondRecord()
// {
//   console.log("Recording");
//   recorder.start();
// }

// async function secondPlay()
// {
//   console.log("Stop");
//   const recording = await recorder.stop();
//   const player = new Tone.Player(recording).toDestination();

//   const url = URL.createObjectURL(recording);
//   const audio = new Audio(url);

//   audio.loop = true;
//   audio.play();

//   player.loop = true;
//   player.autostart = true;
// }